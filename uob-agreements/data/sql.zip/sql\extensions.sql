-- ==========================================================
-- PostgreSQL Extensions
-- ==========================================================


CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";