CHECK (name <> '')
CHECK (code <> '')